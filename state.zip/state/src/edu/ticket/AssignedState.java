package edu.ticket;

public class AssignedState implements TicketState {

    @Override
    public void handle(TicketContext context, String channel, String type) {
        if (type.equals("BUG")) {
            System.out.println("Assigned to engineering");
        } else {
            System.out.println("Assigned to support");
        }

        context.setState(new InProgressState());
    }
}
