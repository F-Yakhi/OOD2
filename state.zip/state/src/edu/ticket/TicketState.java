package edu.ticket;

public interface TicketState {
    void handle(TicketContext context, String channel, String type);
}