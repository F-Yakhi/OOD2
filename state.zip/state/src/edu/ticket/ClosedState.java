package edu.ticket;

public class ClosedState implements TicketState {

    @Override
    public void handle(TicketContext context, String channel, String type) {
        System.out.println("Ticket closed");
    }
}
