package edu.ticket;

public class TicketContext {

    private TicketState state;

    public TicketContext() {
        this.state = new NewState();
    }

    public void setState(TicketState state) {
        this.state = state;
    }

    public void handle(String channel, String type) {
        state.handle(this, channel, type);
        System.out.println("Logging ticket handling");
    }
}
