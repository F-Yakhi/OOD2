package edu.ticket;

public class InProgressState implements TicketState {

    @Override
    public void handle(TicketContext context, String channel, String type) {
        System.out.println("Working on ticket");

        if (type.equals("BUG")) {
            System.out.println("Sending bug response");
        } else {
            System.out.println("Sending generic response");
        }

        context.setState(new ResolvedState());
    }
}