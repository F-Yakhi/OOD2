public class Main {
    public static void main(String[] args) {

        TicketContext ticket = new TicketContext();

        ticket.handle("WEB", "BUG");
        System.out.println("------------");
        ticket.handle("EMAIL", "QUESTION");
    }
}
