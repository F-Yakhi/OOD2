import edu.ticket.TicketContext;
import edu.ticket.WebReceiveStrategy;
import edu.ticket.BugAssignStrategy;
import edu.ticket.BugResponseStrategy;

public class Main {
    public static void main(String[] args) {

        TicketContext ticket = new TicketContext(
                new WebReceiveStrategy(),
                new BugAssignStrategy(),
                new BugResponseStrategy()
        );

        ticket.handle();
        System.out.println("-----");
        ticket.handle();
        System.out.println("-----");
        ticket.handle();
        System.out.println("-----");
        ticket.handle();
    }
}