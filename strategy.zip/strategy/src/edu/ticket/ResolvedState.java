package edu.ticket;

public class ResolvedState implements TicketState {
    public void handle(TicketContext context) {
        System.out.println("Ticket resolved");
        context.setState(new ClosedState());
    }
}
