package edu.ticket;

public class BugResponseStrategy implements ResponseStrategy {
    public void respond() {
        System.out.println("Sending bug response");
    }
}


