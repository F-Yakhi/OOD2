package edu.ticket;

public class BugAssignStrategy implements AssignStrategy {
    public void assign() {
        System.out.println("Assigned to engineering");
    }
}


