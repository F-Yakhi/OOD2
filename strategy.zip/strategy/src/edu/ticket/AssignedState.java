package edu.ticket;

public class AssignedState implements TicketState {
    public void handle(TicketContext context) {
        context.getAssignStrategy().assign();
        context.setState(new InProgressState());
    }
}