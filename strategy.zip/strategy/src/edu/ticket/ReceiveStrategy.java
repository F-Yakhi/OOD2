package edu.ticket;

public interface ReceiveStrategy {
    void receive();
}