package edu.ticket;

public interface ResponseStrategy {
    void respond();
}
