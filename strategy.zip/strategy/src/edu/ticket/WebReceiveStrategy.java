package edu.ticket;

public class WebReceiveStrategy implements ReceiveStrategy {
    public void receive() {
        System.out.println("Received from web");
    }
}

