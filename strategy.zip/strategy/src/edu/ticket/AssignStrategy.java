package edu.ticket;

public interface AssignStrategy {
    void assign();
}
