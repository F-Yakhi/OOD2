package edu.ticket;

public class ClosedState implements TicketState {
    public void handle(TicketContext context) {
        System.out.println("Ticket closed");
    }
}
